export class Product {
  // productName!: string;
  // productId!: number;
  // shtDes!: string;
  // detDes!: string;
  // category!: string;
  // startingPrice!: number;
  // bids!: object;

}
